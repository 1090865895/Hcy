package com.example.bluertooth;

import cn.jpush.android.service.JCommonService;

public class JiGuanService extends JCommonService {


}
