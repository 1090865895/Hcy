package com.example.bluertooth;

/**
 *
 */

public class Params {
    public static final int MESSAGE_READ = 1;
    public static final int MESSAGE_XINGGE = 123;
    public static final String BLUETOOTH_UUID = "00001101-0000-1000-8000-00805F9B34FB";

}
